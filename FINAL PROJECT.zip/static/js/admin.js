// ======================================================================
// admin.js (Dashboard Functionality)
// Handles sidebar navigation for the admin dashboard.
// ======================================================================

document.addEventListener('DOMContentLoaded', () => {
    const sidebarLinks = document.querySelectorAll('.sidebar a[data-target]');
    const contentSections = document.querySelectorAll('.content-section');

    sidebarLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault(); // Prevent default link behavior
            
            const targetId = link.getAttribute('data-target');

            // 1. Deactivate all links and content sections
            sidebarLinks.forEach(l => l.classList.remove('active'));
            contentSections.forEach(s => s.classList.remove('active'));

            // 2. Activate the clicked link and corresponding content section
            link.classList.add('active');
            
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.add('active');
            } else {
                console.error(`Admin content section with ID '${targetId}' not found.`);
            }
        });
    });

    // Optional: Auto-select the section based on URL hash on load
    const initialHash = window.location.hash.substring(1);
    if (initialHash) {
        const initialLink = document.querySelector(`.sidebar a[data-target="${initialHash}"]`);
        if (initialLink) {
            initialLink.click();
        }
    }
});