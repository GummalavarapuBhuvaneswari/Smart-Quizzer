// ======================================================================
// results.js (AI Suggestions Logic & Chart Initialization)
// Handles dynamic content loading, status updates, and AI suggestions.
// ======================================================================

// Helper function to simulate a realistic delay for fetching data
const simulateDelay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Simulates fetching project data and determines the overall status.
 * @returns {object} containing project data.
 */
function fetchProjectData() {
    // In a real application, this would be an AJAX call to your backend
    return {
        health: 'healthy', // 'healthy', 'warning', 'critical'
        completionRate: 92,
        velocity: [15, 20, 25, 30],
        labels: ['Sprint 1', 'Sprint 2', 'Sprint 3', 'Sprint 4']
    };
}

/**
 * Simulates the AI model generating complex, multi-faceted suggestions.
 * @returns {Array<object>} A list of AI suggestions.
 */
async function fetchAISuggestions() {
    await simulateDelay(1500); // Simulate network latency

    return [
        { 
            type: "Performance Optimization", 
            suggestion: "The AI detects a potential database query slowdown (average +40ms) during peak load. **Recommendation:** Implement a 15-minute cache layer for read-heavy API endpoints.",
            icon: "fas fa-rocket",
            urgency: "High"
        },
        { 
            type: "Budget & Resource Allocation", 
            suggestion: "Analysis shows the QA team is currently over-resourced for the current test load. **Recommendation:** Temporarily reallocate one QA engineer to assist with documentation/onboarding tasks for cost efficiency.",
            icon: "fas fa-dollar-sign",
            urgency: "Medium"
        },
        { 
            type: "Security Vulnerability Alert", 
            suggestion: "The dependency 'auth-lib@1.2.0' has a known minor vulnerability (CVE-2023-4567). **Action:** Upgrade dependency to 'auth-lib@1.2.1' immediately.",
            icon: "fas fa-shield-alt",
            urgency: "Critical"
        },
        { 
            type: "Future-Pacing Recommendation", 
            suggestion: "Given the high velocity, the AI suggests **pulling forward the deployment of the Mobile Push Notification feature** into the next sprint to reduce pressure on the end-of-project timeline.",
            icon: "fas fa-forward",
            urgency: "Low"
        }
    ];
}

/**
 * Initializes the Chart.js visualization for project velocity.
 */
function initializeChart(data) {
    const ctx = document.getElementById('velocityChart').getContext('2d');
    
    // Destroy previous chart instance if it exists (for re-runs)
    if (window.velocityChartInstance) {
        window.velocityChartInstance.destroy();
    }

    window.velocityChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Story Points Completed',
                data: data.velocity,
                borderColor: '#4CAF50', // Primary color
                backgroundColor: 'rgba(76, 175, 80, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                title: {
                    display: true,
                    text: 'Weekly Velocity Trend'
                }
            },
            scales: {
                y: { beginAtZero: true, title: { display: true, text: 'Points' } },
                x: { grid: { display: false } }
            }
        }
    });
}

/**
 * Renders the fetched AI suggestions into the HTML and updates the status badge.
 * @param {boolean} isManualRun Indicates if the user manually triggered the analysis.
 */
async function renderAISuggestions(isManualRun = false) {
    const listContainer = document.getElementById('ai-suggestion-list');
    const statusBadge = document.getElementById('status-badge');
    
    // Set loading state
    listContainer.innerHTML = `<p style="text-align: center; color: var(--secondary-color);"><i class="fas fa-spinner fa-spin"></i> ${isManualRun ? 'Re-running analysis...' : 'Loading intelligent insights...'}</p>`;
    statusBadge.textContent = 'STATUS: ANALYZING';
    statusBadge.className = 'result-badge badge-warning';

    try {
        const suggestions = await fetchAISuggestions();
        const projectData = fetchProjectData();

        listContainer.innerHTML = ''; // Clear loading message

        suggestions.forEach(item => {
            const suggestionDiv = document.createElement('div');
            suggestionDiv.className = 'suggestion-item';

            // Determine badge color based on urgency
            let urgencyColor = '';
            if (item.urgency === 'Critical') {
                urgencyColor = 'var(--danger-color)';
            } else if (item.urgency === 'High') {
                urgencyColor = 'var(--warning-color)';
            } else {
                urgencyColor = 'var(--primary-color)';
            }
            
            suggestionDiv.innerHTML = `
                <p style="font-size: 0.9rem; margin-bottom: 5px; color: ${urgencyColor};">
                    <i class="fas fa-circle" style="font-size: 0.6rem;"></i> Urgency: <strong>${item.urgency}</strong>
                </p>
                <p>
                    <i class="${item.icon}" style="color: var(--ai-suggestion-color); margin-right: 8px;"></i>
                    <strong>${item.type}:</strong> ${item.suggestion}
                </p>
            `;
            listContainer.appendChild(suggestionDiv);
        });

        // Update final status badge based on data analysis (simulated)
        if (suggestions.some(s => s.urgency === 'Critical')) {
             statusBadge.textContent = 'STATUS: CRITICAL RISK';
             statusBadge.className = 'result-badge badge-danger';
        } else if (suggestions.some(s => s.urgency === 'High')) {
             statusBadge.textContent = 'STATUS: ATTENTION REQUIRED';
             statusBadge.className = 'result-badge badge-warning';
        } else {
             statusBadge.textContent = 'STATUS: HEALTHY';
             statusBadge.className = 'result-badge badge-success';
        }
        
        initializeChart(projectData);

    } catch (error) {
        listContainer.innerHTML = '<p style="color: var(--danger-color); text-align: center;"><i class="fas fa-times-circle"></i> Error fetching AI analysis. Check API connection.</p>';
        console.error("AI Fetch Error:", error);
    }
}

// Run the core function when the page loads
document.addEventListener('DOMContentLoaded', () => {
    // Initialize chart with initial data before AI suggestions finish
    const initialData = fetchProjectData();
    initializeChart(initialData);

    // Fetch and render AI suggestions
    renderAISuggestions();
});